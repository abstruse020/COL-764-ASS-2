#!/bin/bash


python lm_rerank.py $1 $2 $3 $4 $5 $6
