#!/bin/bash

python rocchio_rerank.py $1 $2 $3 $4

